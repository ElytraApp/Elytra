//
//  SafariExtensionScript.js
//  safari-subscribe
//
//  Created by Nikhil Nigade on 13/07/21.
//  Copyright © 2021 Dezine Zync Studios. All rights reserved.
//

var thisPageLinkObjects = null;

function objectFromLink(theLink) {
  
  let linkObject = new Object();
  
  linkObject.href = theLink.href;
  linkObject.type = theLink.type;
  linkObject.title = theLink.title;
  
  return linkObject;
  
}

function isValidFeedLink(theLink) {
  
  let isValid = false;
  
  // don't let comment feeds pass through.
  if (theLink.href?.includes("/comments")) {
    return isValid;
  }
  
  switch (theLink.type) {
      
    case "application/atom+xml":
    case "application/x.atom+xml":
    case "application/rss+xml":
    case "application/feed+json":
    case "application/json":
      // These types do not require other criteria.
      isValid = (theLink.href != null);
      
    case "text/xml":
    case "application/rdf+xml":
      // These types require a title that has "RSS" in it.
      if (theLink.title && theLink.title.search(/RSS/i) != -1) {
        isValid = (theLink.href != null);
      }
  }
  
  return isValid;
  
}

function scanForFeeds() {
  
  console.debug("Scanning for feeds")
  
  thisPageLinkObjects = []
  
  thisPageLinks = document.querySelectorAll("link[href][rel~='alternate'][type]");
  
  for (thisLink of thisPageLinks) {
    
    if (isValidFeedLink(thisLink)) {
      thisPageLinkObjects.push(objectFromLink(thisLink));
    }
    
  }
  
  console.debug(`Found ${thisPageLinks.length} links on this page.`)
  
}

function subscribeToFeed(theFeed) {
  let feedURL = theFeed.href;
  if (!feedURL.startsWith('elytra:')) {
    feedURL = 'feed:' + feedURL;
  }
  
  console.debug("Subscribing to", feedURL)
  
  safari.extension.dispatchMessage("subscribeToFeed", { "url": feedURL });
  
}

function messageHandler(event) {
  
  if (event.name == "toolbarButtonClicked") {
    
    if ((document.location != null) && (thisPageLinkObjects?.length > 0)) {
      const feedToOpen = thisPageLinkObjects[0];
      subscribeToFeed(feedToOpen);
    }
    
  }
  else if (event.name == "ping") {
    
    const shouldValidate = (document.location != null) && (thisPageLinkObjects?.length > 0);
    
    safari.extension.dispatchMessage("pong", {
      "validationID": event.message.validationID,
      "shouldValidate": shouldValidate
    });
    
  }
  else {
    console.log("Unknown event", event)
  }
  
}

document.addEventListener("DOMContentLoaded", function(event) {
  if ((window.top === window) && (typeof safari != 'undefined') && (document.location != null)) {
    console.debug("Loaded Elytra Subscribe to Feed Safari Extension")
    safari.self.addEventListener("message", messageHandler, false)
    scanForFeeds();
  }
});
